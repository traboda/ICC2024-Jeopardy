document.getElementById('goBack').addEventListener('click', () => {
    window.history.back();
});